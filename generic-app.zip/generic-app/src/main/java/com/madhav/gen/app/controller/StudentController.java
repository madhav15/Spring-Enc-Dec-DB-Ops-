package com.madhav.gen.app.controller;

import com.madhav.gen.app.model.Student;
import com.madhav.gen.app.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;
import java.util.Random;

@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/save")
    public String save() throws Exception {

        Student student = new Student();
        int id = new Random().nextInt();
        student.setId(id);
        student.setName("Madhav");
        student.setAddress("Pune");
        student.setAge(20);

        studentService.save(student);

        Thread.sleep(5000);

        Optional<Student> optional = studentService.getStudent(id);
        System.out.println(optional.get());
        return "success";
    }
}
