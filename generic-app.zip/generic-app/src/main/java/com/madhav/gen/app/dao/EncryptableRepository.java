package com.madhav.gen.app.dao;

import com.madhav.gen.app.util.EncryptableEntity;
import com.madhav.gen.app.util.EncryptionUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class EncryptableRepository<T, ID> {

    private final JpaRepository<T, ID> repository;

    public EncryptableRepository(JpaRepository<T, ID> repository) {
        this.repository = repository;
    }

    public T save(T entity) throws Exception {
        // Encrypt the data before saving
        EncryptionUtils.encryptFields(entity);
        return repository.save(entity);
    }

    public Optional<T> findById(ID id) throws Exception {
        // Fetch the entity
        Optional<T> entity = repository.findById(id);
        if (entity.isPresent()) {
            // Decrypt the data before returning
            T value = entity.get();
            EncryptionUtils.decryptFields(value);
        }
        return entity;
    }

    public void deleteById(ID id) {
        repository.deleteById(id);
    }
}
