package com.madhav.gen.app.util;

import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class EncryptableEntity {

    public abstract String getEncryptedField(); // Fields to be encrypted
    public abstract void setEncryptedField(String encryptedField);
}

