package com.madhav.gen.app.service;


import com.madhav.gen.app.dao.EncryptableRepository;
import com.madhav.gen.app.dao.StudentRepository;
import com.madhav.gen.app.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService {

    private final EncryptableRepository<Student, Integer> encryptableRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.encryptableRepository = new EncryptableRepository<>(studentRepository);
    }

    public Student save(Student student) throws Exception {
        return encryptableRepository.save(student);
    }

    public Optional<Student> getStudent(Integer id) throws Exception {
        return encryptableRepository.findById(id);
    }
}
