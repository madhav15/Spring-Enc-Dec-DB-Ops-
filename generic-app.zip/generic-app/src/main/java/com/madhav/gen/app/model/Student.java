package com.madhav.gen.app.model;

import com.madhav.gen.app.util.Encrypt;
import com.madhav.gen.app.util.EncryptableEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "student")
@Data
public class Student {

    @Id
    private int id;

    @Encrypt
    private String name;

    @Encrypt
    private String address;

    private int age;

}
